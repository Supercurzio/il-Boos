<?php

//don't allow direct access via url
if ( ! defined('ABSPATH') ) {
    exit();
}

function betpress_submit_bet_slip() {

    //codex says i MUST do this if
    if (is_admin() === true) {
        
        $user_ID = get_current_user_id();
        
        $users_db_points = get_user_meta($user_ID, 'bp_points', true);
        
        $users_points = $users_db_points === '' ? get_option('bp_starting_points') : $users_db_points;
        
        $errors = array();
        
        $bet_stake = betpress_sanitize($_POST['bet_stake']);
        
        $min_stake = get_option('bp_min_stake');
        
        $max_stake = get_option('bp_max_stake');
 		
        $slip = betpress_get_user_unsubmitted_slip($user_ID);
        
        if ( ! $slip ) {
            
            $errors [] = __('<font color="red">ERRORE Seleziona una opzione prima.</font>', 'BetPress');
            
        } else {
            
		    $previous_slips = betpress_get_user_submitted_slips($user_ID);
		  
            $bet_options_ids = unserialize($slip['bet_options_ids']);
            $conta=0;
            $is_social=0;
            $mess="Scegli una sola sfida su cui puntare";
            foreach ($bet_options_ids as $bet_option_ID => $bet_option_odd) {
                $conta++;
                $check_social = betpress_get_bet_option($bet_option_ID);
                if($check_social['ammo']>0){
                    $is_social++;
                }
            }
            if($conta>1 && $is_social>0){
                
                $errors [$bet_option_details['bet_event_id'] . '-creator'] = sprintf(
                    
                    __('<font color="red">ERRORE: Non puoi creare scommesse multiple social %s .</font>', 'BetPress'),
                    
                   $mess
                    
                    );
            }else{
      
      
            foreach ($bet_options_ids as $bet_option_ID => $bet_option_odd) {

                $bet_option_details = betpress_get_bet_option($bet_option_ID);
				
			                  //check if the user created the game

                if ($bet_option_details['added_by_user_id'] == $user_ID) {


                    $errors [$bet_option_details['bet_event_id'] . '-creator'] = sprintf(

                        __('<font color="red">ERRORE:Non puoi puntare su %s perch&egrave sei il creatore.</font>', 'BetPress'),

                        $bet_option_details['bet_event_name']

                    );


                }

                //check if bet_option is active Supercurzio
                
                if ($bet_option_details['is_active'] == "0") {
                    
                    
                    $errors [$bet_option_details['bet_event_id'] . '-creator'] = sprintf(
                        
                        __('<font color="red">ATTENZIONE: %s Puntata NON disponibile al momento riprova pi&ugrave tardi.</font>', 'BetPress'),
                        
                        $bet_option_details['bet_event_name']
                        
                        );
                    
                    
                }else{
                    //check if stake can be paid Supercurzio
                    If ($bet_option_details['bet_event_cat_balance']>0){
                    $opt_ammo = betpress_sanitize($bet_option_details['opt_ammo']);
                    $opt_winnings = betpress_sanitize($bet_option_details['opt_winnings']);
                    $vincita = $bet_stake; 
                    $vincita *= $bet_option_odd;
                    $vincite_totali=$vincita + $opt_winnings;
                   // echo $bet_stake;//DEBUG
                    //echo $vincita;;//DEBUG
                    //echo $vincite_totali;//DEBUG
                    //echo $opt_winnings;//DEBUG
                    //echo $opt_ammo;//DEBUG
                    
                    
                    if ($bet_option_details['opt_ammo'] < $vincite_totali) {
                        
                        
                        $errors [$bet_option_details['bet_event_id'] . '-creator'] = sprintf(
                            
                            __('<font color="red">ATTENZIONE: Puntata NON coperta %s diminuisci la puntata.</font>', 'BetPress'),
                            
                            $bet_option_details['bet_event_name']
                            
                            );
                        
                        
                    }else{
                       // echo "Funziona controllo copertura";//DEBUG
                    }
                   
                    //
                    
                    //echo "Attiva";//DEBUG
                }
                }
            

                
                //check if bet already exists for this bet event

                foreach ($previous_slips as $previous_slip) {


                    $previous_slip_bet_options_ids = unserialize($previous_slip['bet_options_ids']);


                    foreach ($previous_slip_bet_options_ids as $previous_slip_bet_option_ID => $previous_slip_bet_option_odd) {


                        $previous_slip_bet_option_details = betpress_get_bet_option($previous_slip_bet_option_ID);


                        if ($previous_slip_bet_option_details['bet_event_id'] == $bet_option_details['bet_event_id']) {


                            $errors [$bet_option_details['bet_event_id'] . '-duplicate'] = sprintf(

                                __('<font color="red">ERRORE: Non puoi puntare su %s perch&egrave ci hai gi&agrave puntato sopra.</font>', 'BetPress'),

                                $bet_option_details['bet_event_name']

                            );


                        }


                    }


                }


                //check for passed deadline

			  
                $seconds_to_close_bets_earlier = (int) get_option('bp_close_bets');

                $bet_event_close_time = $bet_option_details['deadline'] - $seconds_to_close_bets_earlier;
                
                if ($bet_event_close_time < time()) {
                    
                    $errors [$bet_option_details['bet_event_name']] = sprintf(
                            __('<font color="red">Siamo oltre la deadline per %s .</font>', 'BetPress'),
                            $bet_option_details['bet_event_name']
                        );
                    
                }
            }
            }//
            //check for same slip
            $user_awaiting_slips = betpress_get_user_awaiting_slips($user_ID);
            
            foreach ($user_awaiting_slips as $awaiting_slip) {
                
                $awaiting_slip_bet_options = unserialize($awaiting_slip['bet_options_ids']);
                
                $differences = array_diff_assoc($bet_options_ids, $awaiting_slip_bet_options);
                
                $count_awaiting_slip = count($awaiting_slip_bet_options);
                
                $count_unsubmitted_slip = count($bet_options_ids);
                
                if ( ($differences === array()) && ($count_awaiting_slip === $count_unsubmitted_slip) ) {
                    
                    $errors ['same_slip'] = __('<font color="red">ERRORE: Hai gi&agrave una puntata su questa opzione</font>', 'BetPress');
                }
            }
            
            if (get_option('bp_only_int_stakes') === BETPRESS_VALUE_YES) {

                if ($bet_stake - intval($bet_stake) !== 0) {

                    $errors [] = __('<font color="red">ERRORE:La puntata deve essere un numero intero.</font>', 'BetPress');
                }
            }

            if ($users_points < $bet_stake) {

                $errors [] = __('<font color="red">ERRORE:Non hai abbastanza Social points $P.</font>', 'BetPress');
            }

            if ($bet_stake < $min_stake) {

                $errors [] = sprintf(__('<font color="red">ERRORE:La puntata &egrave inferiore al minimo di %s</font>', 'BetPress'), $min_stake);
                
            } else {

                $min_stake_ok = true;
            }

            if ($bet_stake > $max_stake) {

                $errors [] = sprintf(__('<font color="red">ERRORE:La puntata supera il limite massimo di %s</font>', 'BetPress'), $max_stake);
            }

            if ($bet_stake <= 0 && isset($min_stake_ok)) {

                $errors [] = __('<font color="red">ERRORE:La puntata deve essere maggiore di 0.</font>', 'BetPress');
            }
        }
        
        if ($errors) {
            
            //show errors
            foreach($errors as $error) {
                
                $pass['error_message'] = $error;
                betpress_get_view('error-message', '', $pass);
            }

            //take bet options and make them array
            $bet_option_ids = unserialize($slip['bet_options_ids']);

            //show the slip
            if ($slip) {
                betpress_render_bet_options($bet_option_ids);
            }
            
        } else {
            
            //calculate possible winnings
            $possible_winnings = $bet_stake;
            
            $bet_options_ids = unserialize($slip['bet_options_ids']);
            
            foreach ($bet_options_ids as $bet_option_ID => $bet_option_odd) {
                
                $possible_winnings *= $bet_option_odd;

            }
            
            $possible_winnings_rounded = betpress_floordec($possible_winnings);
                        
            //calculate new points
            $bet_stake_rounded = betpress_floordec($bet_stake);
            $updated_points = $users_points - $bet_stake_rounded;
           
           
            
            //update the points
            update_user_meta($user_ID, 'bp_points', (string)$updated_points);
            
            //make sure its updated
            if (strcmp(get_user_meta($user_ID, 'bp_points', true), (string)$updated_points) !== 0) {
                wp_die('DB error.');
            }
            //Aggiungo cambiamento di is_active
            
            //Aggiungo la possibile vincita alle altre della opzione Supercurzio
            
            
            foreach ($bet_options_ids as $bet_option_ID => $bet_option_odd) {
               
                //ch
                
                if ($bet_option_details['bet_event_cat_balance'] > 0) {
                    $bet_option_details = betpress_get_bet_option($bet_option_ID);
                    $option_odd = betpress_sanitize($bet_option_details['bet_option_odd']);
                    $opt_winnings = $bet_option_details['opt_winnings'];
                    $possible_winning = $bet_stake;
                    $possible_winning *= $option_odd ;
                    $possible_total_winnings = $opt_winnings + $possible_winning ;
                    
                    $is_updated = betpress_update(
                        'bet_options',
                        array(
                            'opt_winnings' =>  $possible_total_winnings,
                        ),
                        array(
                            'bet_option_id' => $bet_option_details['bet_option_id'],
                        )
                        );
                    
                    //controllo is _active
                    $bet_option_details = betpress_get_bet_option($bet_option_ID);//riprendo dettagli dopo ultimo inserimento
                    $opt_winnings = $bet_option_details['opt_winnings'];
                    $opt_ammo = $bet_option_details['opt_ammo'];
                    $cashback = $opt_ammo - $opt_winnings;
               
                    if($cashback < $option_odd){// quello giusto � <
              
                        $is_unactive = betpress_update(
                            'bet_options',
                            array(
                                'is_active' =>  "0",
                            ),
                            array(
                                'bet_option_id' => $bet_option_details['bet_option_id'],
                            )
                            );
                    }
              
                        
                  
                    
                    //echo"FUNZIONA, � social";//DEBUG
                    //Aggiungo la puntata agli altri opt_ammo delle opzioni SUPERCURZIO
                    //echo$bet_option_details['bet_option_id'];//DEBUG
                    //echo$bet_option_details['bet_event_cat_id'];//DEBUG
                    $siblings_opt = betpress_get_sibling_categories_except_current($bet_option_details['bet_event_cat_id'], $bet_option_details['bet_option_id']);
                   // if($siblings_opt==FALSE){echo "query sbagliata";}//DEBUG
              
                    foreach ($siblings_opt as $bet_option_ID => $sib) {
                  
                        if ($sib['bet_option_id'] !== $bet_option['bet_option_id']) {
                         
                            $bet_option_sib_details = betpress_get_bet_option($sib['bet_option_id']);
                            $option_opt_ammo = betpress_sanitize($bet_option_sib_details['opt_ammo']);
                            $total_opt_ammo= $option_opt_ammo + $bet_stake;
                          
                            $is_updated = betpress_update(
                                'bet_options',
                                array(
                                    'opt_ammo' =>  $total_opt_ammo,
                                ),
                                array(
                                    'bet_option_id' => $sib['bet_option_id'],
                                )
                                );
                    
                            //controllo is_active per attivare nel caso
                            $bet_option_sib_details = betpress_get_bet_option($sib['bet_option_id']);
                            $option_opt_ammo = betpress_sanitize($bet_option_sib_details['opt_ammo']);
                            $total_opt_ammo= $option_opt_ammo + $bet_stake;
                            $opt_sib_winnings = $bet_option_sib_details['opt_winnings'];
                            $opt_sib_ammo = $bet_option_sib_details['opt_ammo'];
                            $cashback_sib = $opt_sib_ammo - $opt_sib_winnings;

                            if($cashback_sib > $option_odd){// quello gisuto � >
                                
                                $is_active = betpress_update(
                                    'bet_options',
                                    array(
                                        'is_active' =>  "1",
                                    ),
                                    array(
                                        'bet_option_id' => $bet_option_sib_details['bet_option_id'],
                                    )
                                    );
                            }
                        }else {
                        //    echo"Nada";
                        }//debug
                           
                        
                    }
                    
                }else
                { 
                    //echo"� una scommessa normale";
                }//DEBUG 
            }
            
            
            
            $active_leaderboard = betpress_get_active_leaderboard();
            
            //update the slip
            $is_updated = betpress_update(
                    'slips',
                    array(
                        'status' => BETPRESS_STATUS_AWAITING,
                        'winnings' => $possible_winnings_rounded,
                        'stake' => $bet_stake_rounded,
                        'date' => time(),
                        'leaderboard_id' => $active_leaderboard['leaderboard_id'],
                    ),
                    array(
                        'user_id' => $user_ID,
                        'status' => BETPRESS_STATUS_UNSUBMITTED,
                    )
                );
            
            if (false !== $is_updated) {
                
                $pass['success_message'] = esc_attr__('Your bet slip has been submitted.', 'BetPress');
                betpress_get_view('success-message', '', $pass);
                
            } else {
                wp_die('DB error.');
            }
        }
    }
    //codex says to use wp_die in the end
    wp_die();
}

add_action('wp_ajax_submit_bet_slip', 'betpress_submit_bet_slip');
add_action('wp_ajax_nopriv_submit_bet_slip', 'betpress_submit_bet_slip');