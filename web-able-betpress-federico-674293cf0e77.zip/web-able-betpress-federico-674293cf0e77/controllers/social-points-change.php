<?php

//don't allow direct access via url
if ( ! defined('ABSPATH') ) {
    exit();
}

function betpress_social_points_change() {

    //codex says i MUST do this if
    if (is_admin() === true) {
        
        $user_ID = get_current_user_id();
        
        $balance_social = get_user_meta($user_ID, 'mycred_default', true);
				
        printf(__('Your Social points: %s', 'BetPress'), $balance_social);

        
    }
    
    //codex says i MUST use wp_die
    wp_die();
}

add_action('wp_ajax_points_change', 'betpress_social_points_change');
add_action('wp_ajax_nopriv_points_change', 'betpress_social_points_change');

?>