<?php

//don't allow direct access via url
if ( ! defined('ABSPATH') ) {
    exit();
}

function betpress_add_prom_sport_front_controller ($atts) {

    $user_ID = get_current_user_id();

    if ( ! $user_ID ) {
        return;
    }
    
    //set default attributes
    $attributes = shortcode_atts(
        array(
            //
        ), $atts
    );

    ob_start();

    
    if (isset($_POST['add_prom_sport2'])) {
        
        $exe = betpress_insert_prom_sport2();
    }else {
        echo" manca add_prom_sport2";
        if (isset($_POST['add_prom_sport'])) {
            
            
            $exe = betpress_add_prom_sport();
            
            
        } else {
            $pass['sports'] = betpress_get_structured_xml_sports();
            betpress_get_view('add-prom-sport', 'shortcodes', $pass);
            echo"fine ciclo, manca add_prom_sport";
            
        }
    }
    
 
   
            
    
return ob_get_clean();
}
add_shortcode('betpress_add_prom_sport', 'betpress_add_prom_sport_front_controller');

function betpress_add_prom_sport() {
    
    $required_input = array('sport', 'event', 'bet_event', 'category_name');
    
    foreach ($required_input as $field) {
        
        if (empty($_POST[$field])) {
            
            return false;
            
        }
        
    }
    
    $category_name = betpress_sanitize($_POST['category_name']);  // SUPERCURZIO per promesse su tuttep le categorie
   // $category_name = "Match Result";
    if (strlen($category_name) < 1) {
        
        return false;
        
    }
    
    $sport_name = betpress_sanitize($_POST['sport']);
    
    if (strlen($sport_name) < 1) {
        
        return false;
        
    }
    
    if (betpress_is_sport_exists($sport_name)) {
        
        $sport_row = betpress_get_sport_by_name($sport_name);
        
        $sport_ID = $sport_row['sport_id'];
        
    } else {
        
        $max_order = betpress_get_sports_max_order();
        
        $sport_ID = betpress_insert(
            'sports',
            array(
                'sport_name' => $sport_name,
                'sport_sort_order' => ++ $max_order,
            )
            );
        
    }
    
    betpress_register_string_for_translation('sport-' . $sport_name, $sport_name);
    
    $event_name = betpress_sanitize($_POST['event']);
    
    if (strlen($event_name) < 1) {
        
        return false;
        
    }
    
    if (betpress_is_event_exists($event_name)) {
        
        $event_row = betpress_get_event_by_name($event_name);
        
        $event_ID = $event_row['event_id'];
        
    } else {
        
        $max_order = betpress_get_events_max_order($sport_ID);
        
        $event_ID = betpress_insert(
            'events',
            array(
                'event_name' => $event_name,
                'event_sort_order' => ++ $max_order,
                'sport_id' => $sport_ID,
            )
            );
        
    }
    
    betpress_register_string_for_translation('event-' . $event_name, $event_name);
    
    $bet_event_name = betpress_sanitize($_POST['bet_event']);
    
    if (strlen($bet_event_name) < 1) {
        
        return false;
        
    }
    
    
    $bet_event_deadlines = betpress_get_bet_event_by_name ($bet_event_name, $event_ID);
    $bet_event_deadline = $bet_event_deadlines['deadline'];
   
    
    $teams = explode(" - ", $bet_event_name);
  //  echo $teams[0]; // piece1
   // echo $teams[1]; // piece2
    
    $pass['teams'] = $teams;
    $pass['teams0'] = $teams[0];
    $pass['teams1'] = $teams[1];
    $pass['bet_event_deadline'] = $bet_event_deadline;
    $pass['category_name'] = $category_name;
    $pass['category_id'] = $category_ID;
    $pass['event_id'] = $event_ID;
    $pass['sport_id'] = $sport_ID;
    $pass['bet_event_name'] = $bet_event_name;
    $pass['event_name']= $event_name;
    $pass['sport_name']= $sport_name;
    betpress_get_view('add-prom-sport2', 'shortcodes', $pass);
    
   return true; 
}

function betpress_insert_prom_sport2() {
    $required_input = array('prom_sport_option_name','sport_id', 'event_id', 'bet_event_name', 'category_name','promessa');
    
    foreach ($required_input as $field) {
        
        if (empty($_POST[$field])) {
            
            return false;
            
        }
        
    }
    
    $category_name = betpress_sanitize($_POST['category_name']);  // SUPERCURZIO per promesse su tuttep le categorie
    // $category_name = "Match Result";
    if (strlen($category_name) < 1) {
        
        return false;
        
    }
    
    $sport_name = betpress_sanitize($_POST['sport_name']);
    
    if (strlen($sport_name) < 1) {
        
        return false;
        
    }
    
    if (betpress_is_sport_exists($sport_name)) {
        
        $sport_row = betpress_get_sport_by_name($sport_name);
        
        $sport_ID = $sport_row['sport_id'];
        
    } else {
        
        $max_order = betpress_get_sports_max_order();
        
        $sport_ID = betpress_insert(
            'sports',
            array(
                'sport_name' => $sport_name,
                'sport_sort_order' => ++ $max_order,
            )
            );
        
    }
    
    betpress_register_string_for_translation('sport-' . $sport_name, $sport_name);
    
    $event_name = betpress_sanitize($_POST['event_name']);
    
    if (strlen($event_name) < 1) {
        
        return false;
        
    }
    
    if (betpress_is_event_exists($event_name)) {
        
        $event_row = betpress_get_event_by_name($event_name);
        
        $event_ID = $event_row['event_id'];
        
    } else {
        
        $max_order = betpress_get_events_max_order($sport_ID);
        
        $event_ID = betpress_insert(
            'events',
            array(
                'event_name' => $event_name,
                'event_sort_order' => ++ $max_order,
                'sport_id' => $sport_ID,
            )
            );
        
    }
    
    betpress_register_string_for_translation('event-' . $event_name, $event_name);
    
    $bet_event_name = betpress_sanitize($_POST['bet_event_name']);
    
    if (strlen($bet_event_name) < 1) {
        
        return false;
        
    }
    
    $promessa = betpress_sanitize($_POST['promessa']);
    
    if (strlen($promessa) < 1) {
        
        return false;
        
    }
    
    
    if ( ! function_exists( 'wp_handle_upload' ) ) {
        
        require_once( ABSPATH . 'wp-admin/includes/file.php' );
        
    }
    
    
    $upload = wp_handle_upload($_FILES['question_upload'], array('test_form' => false));
    
    
    if (! $upload || isset($upload['error'])) {
        
        return false;
        
    }
    
    $upload_alternativa = wp_handle_upload($_FILES['uploads'], array('test_form' => false));
    
    
    if (! $upload_alternativa || isset($upload_alternativa['error'])) {
        
        return false;
        
    }
    
    $image_path_promessa = $upload['file'];
    $image_url_promessa = $upload['url'];
    
    $image_path_alternativa = $upload_alternativa['file'];
    $image_url_alternativa = $upload_alternativa['url'];
    
    $prom_sport_option_name = $_POST['prom_sport_option_name'];
    $teams = $_POST['teams'];
    $teams = explode("-", $bet_event_name);
    $bet_event_deadline = $_POST['bet_event_deadline'];
    $ammo = 1;
    $u_id = get_current_user_id();
    $username = bp_core_get_username($u_id);
   
    $answer = $_POST['answers'];
    
    echo "username: ";echo $username;
    echo "u_id: ";echo $u_id;
    echo "sport_option_name";echo $prom_sport_option_name;
    echo"ammo:";echo $ammo;
    echo"team0:"; echo $teams[0];
    echo"team1:";echo $teams[1];
    echo"bet_event_name:";echo $bet_event_name;
    echo"event name::";echo $event_name;
    echo"event_id";echo $event_ID;
    echo"sport id:";echo $sport_ID;
    echo"category name";echo $category_name;
    echo"deadline:";echo $bet_event_deadline;
    echo"promessa:";echo $promessa;
    echo"answer:";echo $answer;
    echo '.ciaone';
    
    //inserisco nuovo bet_event come prom
    $max_order = betpress_get_bet_events_max_order($event_ID);
    
    $bet_event_ID = betpress_insert(
        'bet_events',
        array(
            'bet_event_name' => $bet_event_name,
            'deadline' => $_POST['bet_event_deadline'],
            'is_active' => 1,
            'is_featured' => 1,
            'is_prom' => 1,
            'bet_event_sort_order' => ++ $max_order,
            'event_id' => $event_ID,
            'added_by_user_id' => get_current_user_id(),
            'ammo' => 1,
            'date_inserted' => time(),
        )
        );
   //inserisco nuova prom
    $max_order = betpress_get_prom_events_max_order($event_ID);
    
    $prom_event_ID = betpress_insert(
        'prom_events',
        array(
            'prom_event_name' => $bet_event_name,
            'deadline' => $_POST['bet_event_deadline'],
            'is_active' => 1,
            'is_featured' => 1,
            'prom_event_sort_order' => ++ $max_order,
            'event_id' => $event_ID,
            'added_by_user_id' => get_current_user_id(),
            'ammo' => 1,
            'image_path' => $image_path_promessa,
            'image_url' => $image_url_promessa,
            'date_inserted' => time(),
        )
        );
    //inserisco nuova cat
    $max_order = betpress_get_cats_max_order($bet_event_ID);
    
    $category_ID = betpress_insert(
        'bet_events_cats',
        array(
            'bet_event_cat_name' => $category_name,
            'bet_event_id' => $bet_event_ID,
            'prom_event_id' => $prom_event_ID,
            'bet_event_cat_sort_order' => ++ $max_order,
            'bet_event_cat_balance' => 1,
        )
        );
    
    
    $max_order = betpress_get_bet_options_max_order($category_ID);
    
    betpress_insert(
        'bet_options',
        array(
            'bet_option_name' => $prom_sport_option_name,
            'bet_option_odd' => 1,
            'bet_option_sort_order' => ++$max_order,
            'bet_event_cat_id' => $category_ID,
            'status' => BETPRESS_STATUS_AWAITING,
            'image_path' => $image_path_alternativa,
            'image_url' => $image_url_alternativa,
            
        )
        );
    
    betpress_register_string_for_translation('bet-option-' . $prom_sport_option_name, $prom_sport_option_name);
    
    //Insert into activities
    $u_id = get_current_user_id();
    $buddy_action='<a href="https://www.ilboos.com/members/'.bp_core_get_username($u_id).'">' . bp_core_get_username($u_id) . '</a> ha fatto una nuova promessa sportiva!';
    $buddy_content='<a href="https://www.ilboos.com/scommessa-singola/?bet_id='. $bet_event_ID .'">' . $bet_event_name . '</a>   Seguila e vedi se e di parola!';
    $bet_bp_activity_ID = bp_activity_insert(
        'ilboos_bp_activity',
        array(
            'user_id' => $u_id,
            'component' => 'betpress',
            'type' => 'activity_update',
            'action' => $buddy_action,
            'content' => $buddy_content,
            'item_id' => $bet_event_ID,
            'secondary_item_id' => $prom_event_ID ,
            'date_recorded' => date("Y-m-d H:i:s"),
        )
        );
    
    
    $pass['teams'] = $teams;
    
    betpress_get_view('add-prom-sport3', 'shortcodes', $pass);
    
    
}