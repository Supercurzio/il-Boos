<?php

//don't allow direct access via url
if ( ! defined('ABSPATH') ) {
    exit();
}

function betpress_add_question_front_controller ($atts) {

    $user_ID = get_current_user_id();

    if ( ! $user_ID ) {
        return;
    }
    
    //set default attributes
    $attributes = shortcode_atts(
        array(
            //
        ), $atts
    );

    ob_start();

    if (isset($_POST['add_question'])) {

        if (betpress_add_question()) {

            echo 'Successfully added!';

        } else {

            echo 'Validation failed!';

        }

    }

    betpress_get_view('add-question', 'shortcodes');
    
    return ob_get_clean();
}

add_shortcode('betpress_add_question', 'betpress_add_question_front_controller');

function betpress_add_question() {

    $required_input = array('question', 'prize', 'deadline', 'ammo', 'answers');

    foreach ($required_input as $field) {

        if (empty($_POST[$field])) {

            return false;

        }

    }

    $title = betpress_sanitize($_POST['question']);

    if (strlen($title) < 1) {

        return false;

    }

    $prize = betpress_sanitize($_POST['prize']);

    if ($prize <= 0) {

        return false;

    }

    if ( ( $deadline = strtotime(betpress_sanitize($_POST['deadline'])) ) === false ) {

        return false;

    }
    if ($has_image = strstr($title, '[image]') !== false) {


        if ( ! function_exists( 'wp_handle_upload' ) ) {

            require_once( ABSPATH . 'wp-admin/includes/file.php' );

        }


        $upload = wp_handle_upload($_FILES['question_upload'], array('test_form' => false));


        if (! $upload || isset($upload['error'])) {

            return false;

        }

    }

    $question_ID = betpress_insert(
        'questions',
        array(
            'user_id' => get_current_user_id(),
            'title' => $title,
            'prize' => $prize,
            'deadline' => $deadline,
            'ammo' => betpress_sanitize($_POST['ammo']),
			'image_path' => $has_image ? $upload['file'] : null,
            'image_url' => $has_image ? $upload['url'] : null,
            'balance' => betpress_sanitize($_POST['ammo']),
            'date_inserted' => time(),
        )
    );

    
    //Insert into activities
    $u_id=get_current_user_id();
    $buddy_action='<a href="http://www.ilboos.com/members/'.bp_core_get_username($u_id).'">' . bp_core_get_username($u_id) . '</a> ha fatto una nuova promessa!';
    $buddy_content='<a href="http://www.ilboos.com/scommessa-singola/?bet_id='. $bet_event_ID .'">' . $bet_event_name . '</a>   Seguila!!';
    $bet_bp_activity_ID = bp_activity_insert(
        'ilboos_bp_activity',
        array(
            'user_id' => $u_id,
            'component' => 'betpress',
            'type' => 'question_created',
            'action' => $buddy_action,
            'content' => $title,
            'item_id' => $prize,
            'secondary_item_id' => betpress_sanitize($_POST['ammo']),
            'date_recorded' => date("Y-m-d H:i:s"),
            )
        );
    
    //calculate new balance
    $current_points = get_user_meta($u_id, 'bp_points', true);
    
    $submitted_ammo = $_POST['ammo'];
    
    $new_points = $current_points - $submitted_ammo ;
    
    //update the points
    update_user_meta($u_id, 'bp_points', (string)$new_points);
    
    //make sure its updated
    if (strcmp(get_user_meta($user_ID, 'bp_points', true), (string)$updated_points) !== 0) {
        wp_die('DB error.');
    }
    
    if (! $question_ID) {

        return false;

    }
    
    

    betpress_register_string_for_translation('question-' . $title, $title);

    foreach ($_POST['answers'] as $answer_ID => $answer_title) {

        if (strlen($answer_title) < 1) {

            return false;

        }

        if ($has_image = strstr($answer_title, '[image]') !== false) {

            if ( ! function_exists( 'wp_handle_upload' ) ) {
                require_once( ABSPATH . 'wp-admin/includes/file.php' );
            }

            $image = array(
                'name' => $_FILES['uploads']['name'][$answer_ID],
                'type' => $_FILES['uploads']['type'][$answer_ID],
                'tmp_name' => $_FILES['uploads']['tmp_name'][$answer_ID],
                'error' => $_FILES['uploads']['error'][$answer_ID],
                'size' => $_FILES['uploads']['size'][$answer_ID],
            );

            $upload = wp_handle_upload($image, array('test_form' => false));

            if (! $upload || isset($upload['error'])) {
                return false;
            }

        }

        $answer_ID = betpress_insert(
            'answers',
            array(
                'question_id' => $question_ID,
                'title' => $answer_title,
                'is_correct' => $_POST['correct_answer'] == $answer_ID,
                'image_path' => $has_image ? $upload['file'] : null,
                'image_url' => $has_image ? $upload['url'] : null,
            )
        );

        if (! $answer_ID) {

            return false;

        }

        betpress_register_string_for_translation('answer-' . $answer_title, $answer_title);

    }

    return true;

}