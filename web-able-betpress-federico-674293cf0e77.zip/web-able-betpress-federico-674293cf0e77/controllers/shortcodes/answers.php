<?php


//don't allow direct access via url

if ( ! defined('ABSPATH') ) {

    exit();

}


function betpress_answers_front_controller ($atts) {

    

    //set default attributes

    $attributes = shortcode_atts(

        array(

            //

        ), $atts

    );


    $user_ID = get_current_user_id();

    

    ob_start();

    

    $pass['answers'] = betpress_get_user_answered_questions($user_ID);


    betpress_get_view('answers', 'shortcodes', $pass);

    

    return ob_get_clean();

}


add_shortcode('betpress_answers', 'betpress_answers_front_controller');
