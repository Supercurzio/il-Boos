<?php

//don't allow direct access via url
if ( ! defined('ABSPATH') ) {
    exit();
}

function betpress_add_bettings_front_controller ($atts) {

    $user_ID = get_current_user_id();

    if ( ! $user_ID ) {
        return;
    }
    
    //set default attributes
    $attributes = shortcode_atts(
        array(
            //
        ), $atts
    );

    ob_start();

    if (isset($_POST['add_betting'])) {
		
		$current_points = get_user_meta($user_ID, 'bp_points', true);
		
		$submitted_ammo = $_POST['ammo'];
		
		$check = $current_points - $submitted_ammo ;
		
		 if ($check>=0) {

        	if (betpress_add_betting()) {

           	 echo 'Successfully added!';

        	} else {

            	echo 'Validation failed!';

        	}
			 
		}else {

            	echo 'Validation failed! Not enough Ammo, increase it and try again!';

        	}

    }

    $pass['sports'] = betpress_get_structured_sports();
    betpress_get_view('add-bettings', 'shortcodes', $pass);
    
    return ob_get_clean();
}

add_shortcode('betpress_add_bettings', 'betpress_add_bettings_front_controller');

function betpress_add_betting() {

    $required_input = array('sport', 'event', 'bet_event', 'category', 'bet_options_names', 'bet_options_odds', 'ammo');

    foreach ($required_input as $field) {

        if (empty($_POST[$field])) {

            return false;

        }

    }

    $sport_name = betpress_sanitize($_POST['sport']);

    if (strlen($sport_name) < 1) {

        return false;

    }

    if (betpress_is_sport_exists($sport_name)) {

        $sport_row = betpress_get_sport_by_name($sport_name);

        $sport_ID = $sport_row['sport_id'];

    } else {

        $max_order = betpress_get_sports_max_order();

        $sport_ID = betpress_insert(
            'sports',
            array(
                'sport_name' => $sport_name,
                'sport_sort_order' => ++ $max_order,
            )
        );

    }

    betpress_register_string_for_translation('sport-' . $sport_name, $sport_name);

    $event_name = betpress_sanitize($_POST['event']);

    if (strlen($event_name) < 1) {

        return false;

    }

    if (betpress_is_event_exists($event_name)) {

        $event_row = betpress_get_event_by_name($event_name);

        $event_ID = $event_row['event_id'];

    } else {

        $max_order = betpress_get_events_max_order($sport_ID);

        $event_ID = betpress_insert(
            'events',
            array(
                'event_name' => $event_name,
                'event_sort_order' => ++ $max_order,
                'sport_id' => $sport_ID,
            )
        );

    }

    betpress_register_string_for_translation('event-' . $event_name, $event_name);

    $bet_event_name = betpress_sanitize($_POST['bet_event']);

    if (strlen($bet_event_name) < 1) {

        return false;

    }

    ////////////////////////////////////
    $deadline = $_POST['bet_event_deadline'];
    $id_sportmonks = betpress_get_id_sportmonks($bet_event_name, $deadline );
    
    echo"ciao Pep2!<br>";
    foreach($id_sportmonks as $id) {
        echo $id['id_sportmonks'];
        $sportmonks_id = $id['id_sportmonks'];
    }
    
    //////////////////////////////////////
        $max_order = betpress_get_bet_events_max_order($event_ID);

        $bet_event_ID = betpress_insert(
            'bet_events',
            array(
                'bet_event_name' => $bet_event_name,
                'deadline' => $_POST['bet_event_deadline'],
                'is_active' => 1,
		'is_featured' => 1,
                'bet_event_sort_order' => ++ $max_order,
                'event_id' => $event_ID,
                'added_by_user_id' => get_current_user_id(),
                'ammo' => $_POST['ammo'],
                'date_inserted' => time(),
                'id_sportmonks' => $sportmonks_id,// qui devo mettere lo sportmonks id per poter aggioranre.....fatto
            )
        );
	
        //Insert into activities
	$u_id=get_current_user_id();
	$buddy_action='<a href="https://www.ilboos.com/members/'.bp_core_get_username($u_id).'">' . bp_core_get_username($u_id) . '</a> ha creato una previsione sportiva!';
	$buddy_content='<a href="https://www.ilboos.com/scommessa-singola/?bet_id='. $bet_event_ID .'">' . $bet_event_name . '</a>   accetta la sfida! gioca e vinci!';
	$bet_bp_activity_ID = bp_activity_insert(
		'ilboos_bp_activity',
		array(
                'user_id' => $u_id,
                'component' => 'betpress',
		'type' => 'activity_update',
		'action' => $buddy_action,
                'content' => $buddy_content,
                'item_id' => $bet_event_ID,
                'secondary_item_id' => $_POST['ammo'],
                'date_recorded' => date("Y-m-d H:i:s"),
            )
        );
		
		//calculate new balance
		$current_points = get_user_meta($u_id, 'bp_points', true);
		
		$submitted_ammo = $_POST['ammo'];
		
		$new_points = $current_points - $submitted_ammo ;
		
		 //update the points
            update_user_meta($u_id, 'bp_points', (string)$new_points);
            
            //make sure its updated
            if (strcmp(get_user_meta($user_ID, 'bp_points', true), (string)$updated_points) !== 0) {
                wp_die('DB error.');
            }
    

    betpress_register_string_for_translation('bet-event-' . $bet_event_name, $bet_event_name);

    $category_name = betpress_sanitize($_POST['category']);

    if (strlen($category_name) < 1) {

        return false;

    }

        $max_order = betpress_get_cats_max_order($bet_event_ID);

        $category_ID = betpress_insert(
            'bet_events_cats',
            array(
                'bet_event_cat_name' => $category_name,
                'bet_event_id' => $bet_event_ID,
                'bet_event_cat_sort_order' => ++ $max_order,
				'bet_event_cat_balance' => $_POST['ammo'],
                'id_sm_match' => $sportmonks_id,
                'id_sportmonks' => 1, //1 perch� � solo per 3 Way result, id sportmonk
            )
        );


    betpress_register_string_for_translation('cat-' . $category_name, $category_name);

    foreach ($_POST['bet_options_names'] as $bet_option_ID => $bet_option_name) {

        if (strlen($bet_option_name) < 1) {

            return false;

        }

        $bet_option_odd = betpress_sanitize($_POST['bet_options_odds'][$bet_option_ID]);

        if ($bet_option_odd < 1) {

            return false;
        }

        if ($has_image = strstr($bet_option_name, '[image]') !== false) {

            if ( ! function_exists( 'wp_handle_upload' ) ) {
                require_once( ABSPATH . 'wp-admin/includes/file.php' );
            }

            $image = array(
                'name' => $_FILES['bet_options_images']['name'][$bet_option_ID],
                'type' => $_FILES['bet_options_images']['type'][$bet_option_ID],
                'tmp_name' => $_FILES['bet_options_images']['tmp_name'][$bet_option_ID],
                'error' => $_FILES['bet_options_images']['error'][$bet_option_ID],
                'size' => $_FILES['bet_options_images']['size'][$bet_option_ID],
            );

            $upload = wp_handle_upload($image, array('test_form' => false));

            if (! $upload || isset($upload['error'])) {
                return false;
            }

        }

        $max_order = betpress_get_bet_options_max_order($category_ID);

        betpress_insert(
            'bet_options',
            array(
                'bet_option_name' => $bet_option_name,
                'bet_option_odd' => $bet_option_odd,
                'bet_option_sort_order' => ++$max_order,
                'bet_event_cat_id' => $category_ID,
                'status' => BETPRESS_STATUS_AWAITING,
                'image_path' => $has_image ? $upload['file'] : null,
                'image_url' => $has_image ? $upload['url'] : null,
                'opt_ammo' => $_POST['ammo'],
                'id_sm_match' => $sportmonks_id,
                'id_sportmonks' =>  $sportmonks_id,
            )
        );

        betpress_register_string_for_translation('bet-option-' . $bet_option_name, $bet_option_name);

    }

    return true;

}

function betpress_get_events_per_sport($sport_ID) {

 if (is_admin() !== true) {
        wp_die();
    }
//$name="Football";
//$sport_ID['sport_id'] = betpress_get_sport_by_name($name);
   // echo $sport_ID;
   $sport_ID=1;
//$events = betpress_get_structured_events($id);

   $xml= betpress_get_events_by_sport($sport_ID);
   $events=array();
   foreach ($xml as $event) {
       
       $event_ID = $event['event_id'];
       //echo $event['event_id'];
       $events [$event_ID] =  $event['event_name'];
       
   }
   

    if ($events === false) {
        echo 0;
        wp_die();
    }

    echo json_encode($events);

    wp_die();
}

add_action('wp_ajax_get_events_per_sport', 'betpress_get_events_per_sport');
add_action('wp_ajax_nopriv_get_events_per_sport', 'betpress_get_events_per_sport');

function betpress_get_bet_events_per_event() {

 if (is_admin() !== true) {

        wp_die();

     }

    $sport_ID = betpress_sanitize($_POST['sport_id']);
    $event_ID = betpress_sanitize($_POST['event_id']);
   // $event_ID=1;
   $xml = betpress_get_all_classic_bet_events($event_ID,1,0);//forse qui devo cambiare per far uscire solo match non social
    $bet_events=array();
    foreach ($xml as $bet_event) {
        
        $bet_event_ID = $bet_event['bet_event_id'];
        $bet_event_NAME = $bet_event['bet_event_name'];
        $bet_event_DEADLINE = $bet_event['deadline'];
        $bet_event_ID_SPORTMONKS = $bet_event['id_sportmonks'];
       // echo $event['event_id'];
        $bet_events [$bet_event_ID]['bet_event_name'] = (string)$bet_event['bet_event_name'];
        $bet_events [$bet_event_ID]['deadline'] =  $bet_event['deadline'];
        //$bet_events [$bet_event_ID]['id_sportmonks'] =  $bet_event['id_sportmonks'];
  
        
       
  }  
  
    //$bet_events = betpress_get_structured_xml_bet_events($sport_ID, $event_ID);

    if ($bet_events === false) {
        echo 0;
        wp_die();
    }

    echo json_encode($bet_events);

    wp_die();
}

add_action('wp_ajax_get_bet_events_per_event', 'betpress_get_bet_events_per_event');
add_action('wp_ajax_nopriv_get_bet_events_per_event', 'betpress_get_bet_events_per_event');

function betpress_get_categories_per_bet_event() {
 
if (is_admin() !== true) {

        wp_die();

    }

    $sport_ID = betpress_sanitize($_POST['sport_id']);
    $event_ID = betpress_sanitize($_POST['event_id']);
    $bet_event_ID = betpress_sanitize($_POST['bet_event_id']);

    $xml = betpress_get_all_categories($bet_event_ID);
    $categories=array();
    foreach ($xml as $category) { 
        $category_ID = $category['bet_event_cat_id'];
        $categories [$category_ID] =  $category['bet_event_cat_name'];
    }
    //$categories = betpress_get_structured_xml_categories($sport_ID, $event_ID, $bet_event_ID);

    if ($categories === false) {
        echo 0;
        wp_die();
    }

    echo json_encode($categories);

    wp_die();
}

add_action('wp_ajax_get_categories_per_bet_event', 'betpress_get_categories_per_bet_event');
add_action('wp_ajax_nopriv_get_categories_per_bet_event', 'betpress_get_categories_per_bet_event');

function betpress_get_bet_options_per_category() {
 
if (is_admin() !== true) {

        wp_die();

    }

    $sport_ID = betpress_sanitize($_POST['sport_id']);
    $event_ID = betpress_sanitize($_POST['event_id']);
    $bet_event_ID = betpress_sanitize($_POST['bet_event_id']);
    $category_ID = betpress_sanitize($_POST['category_id']);

    $xml = betpress_get_bet_options ($category_ID);
    $bet_options=array();
    foreach ($xml as $bet_option) {
        
        $bet_option_ID = $bet_option['bet_option_id'];
        $bet_option_NAME = $bet_option['bet_option_name'];
        //$bet_event_DEADLINE = $bet_option['bet_option_odd'];
        // echo $event['event_id'];
        $bet_options[$bet_option_ID]['bet_option_name'] = (string)$bet_option['bet_option_name'];
        $bet_options[$bet_option_ID]['bet_option_odd'] =  $bet_option['bet_option_odd'];
        
        
        
    }  
    //$bet_options = betpress_get_structured_xml_bet_options($sport_ID, $event_ID, $bet_event_ID, $category_ID);

    if ($bet_options === false) {
        echo 0;
        wp_die();
    }

    echo json_encode($bet_options);

    wp_die();
}

add_action('wp_ajax_get_bet_options_per_category', 'betpress_get_bet_options_per_category');
add_action('wp_ajax_nopriv_get_bet_options_per_category', 'betpress_get_bet_options_per_category');
