<?php

//don't allow direct access via url
if ( ! defined('ABSPATH') ) {
    exit();
}

function betpress_questions_front_controller ($atts) {
    
    //set default attributes
    $attributes = shortcode_atts(
        array(
            //
        ), $atts
    );
    
    ob_start();

    if (isset($_POST['answer_id']) && $answer = betpress_get_answer(betpress_sanitize($_POST['answer_id']))) {
        if (betpress_is_user_already_answered_question(betpress_sanitize($_POST['answer_id']))) {
            betpress_get_view('error-message', '', array('error_message' => __('You already answered to this question.', 'BetPress')));
        } else {
            $is_inserted = betpress_insert(
                'answered_questions',
                array(
                    'user_id' => get_current_user_id(),
                    'answer_id' => $_POST['answer_id'],
                    'submitted_at' => time(),
                )
            );

            if ($is_inserted) {
                betpress_get_view('success-message', '', array('success_message' => __('Your answer is saved.', 'BetPress')));
            } else {
                betpress_get_view('error-message', '', array('error_message' => __('Please try again later.', 'BetPress')));
            }
        }
    }
    
    $pass['questions'] = betpress_get_active_questions();

    betpress_get_view('questions', 'shortcodes', $pass);
    
    return ob_get_clean();
}

add_shortcode('betpress_questions', 'betpress_questions_front_controller');

function betpress_get_active_questions() {

    global $wpdb;

    $answers = $wpdb->get_results(
         'SELECT *, q.title AS question_title, a.id AS answer_id, q.image_url AS question_image_url '
        . 'FROM ' . $wpdb->prefix . 'bp_questions AS q '
        . 'JOIN ' . $wpdb->prefix . 'bp_answers AS a '
        . 'ON (q.id = a.question_id) '
        . 'WHERE q.deadline > UNIX_TIMESTAMP() '
        . 'ORDER BY q.deadline DESC',
        ARRAY_A
    );

    $questions = array();

    foreach ($answers as $answer) {
        $questions[$answer['question_id']]['title'] = $answer['question_title'];
		 $questions[$answer['question_id']]['image_url'] = $answer['question_image_url'];
        $questions[$answer['question_id']]['answers'][] = $answer;
    }

    return $questions;
}

function betpress_get_answer($ID) {

    global $wpdb;

    return $wpdb->get_row(
        'SELECT * '
        . 'FROM ' . $wpdb->prefix . 'bp_answers AS a '
        . 'WHERE id = ' . $ID . ' '
        . 'LIMIT 1',
        ARRAY_A
    );
}

function betpress_get_user_answered_questions($user_ID) {

    global $wpdb;

    return $wpdb->get_results(
                'SELECT aq.answer_id, q.title AS question_title, q.image_url AS question_image_url, a.title, a.image_url 

        FROM ' . $wpdb->prefix . 'bp_answered_questions AS aq

        JOIN ' . $wpdb->prefix . 'bp_answers AS a ON (aq.answer_id = a.id)

        JOIN ' . $wpdb->prefix . 'bp_questions AS q ON (a.question_id = q.id)

        WHERE aq.user_id = ' . $user_ID,

        ARRAY_A
    );
}

function betpress_is_user_already_answered_question($answer_ID) {

    $answer = betpress_get_answer($answer_ID);

    $user_answered_questions = betpress_get_user_answered_questions(get_current_user_id());

    foreach ($user_answered_questions as $answered_question) {
        $user_answer = betpress_get_answer($answered_question['answer_id']);

        if ($user_answer['question_id'] == $answer['question_id']) {
            return true;
        }
    }

    return false;
}

function betpress_get_uncalculated_questions() {
    global $wpdb;

    return $wpdb->get_results(
        'SELECT q.id, q.prize, a.id AS correct_answer_id '
        . 'FROM ' . $wpdb->prefix . 'bp_questions AS q '
        . 'JOIN ' . $wpdb->prefix . 'bp_answers AS a ON (q.id = a.question_id) '
        . 'WHERE a.is_correct = 1 '
            . 'AND q.is_calculated = 0 '
            . 'AND q.deadline < UNIX_TIMESTAMP() ',
        ARRAY_A
    );
}

function betpress_get_users_who_answered_with($answer_ID) {
    global $wpdb;

    return $wpdb->get_results(
        'SELECT user_id '
        . 'FROM ' . $wpdb->prefix . 'bp_answered_questions '
        . 'WHERE answer_id = ' . $answer_ID,
        ARRAY_A
    );
}

function betpress_calculate_questions() {
    $questions = betpress_get_uncalculated_questions();

    foreach ($questions as $question) {
        $users = betpress_get_users_who_answered_with($question['correct_answer_id']);

        foreach ($users as $user) {
            $user_db_points = get_user_meta($user['user_id'], 'bp_points', true);

            $user_points = ('' === $user_db_points) ? get_option('bp_starting_points') : $user_db_points;

            $updated_points = $user_points + $question['prize'];

            update_user_meta($user['user_id'], 'bp_points', (string)$updated_points);

            if (strcmp(get_user_meta($user['user_id'], 'bp_points', true), (string)$updated_points) === 0) {

                betpress_insert(
                    'points_log',
                    array(
                        'user_id' => $user['user_id'],
                        'comment_id' => 0,
                        'admin_id' => 0,
                        'answer_id' => $question['correct_answer_id'],
                        'points_amount' => $question['prize'],
                        'date' => time(),
                        'type' => BETPRESS_POINTS,
                    )
                );

            }
        }

        betpress_update(
            'questions',
            array('is_calculated' => 1),
            array('id' => $question['id'])
        );
    }
}
add_action('init', 'betpress_calculate_questions');