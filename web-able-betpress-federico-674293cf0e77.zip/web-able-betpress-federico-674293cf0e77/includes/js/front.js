
jQuery(document).ready(function () {
     //allow datepicker

    jQuery('.jquery-date-time-picker').datetimepicker({

        dateFormat : 'dd-mm-yy',

        timeFormat: 'HH:mm z'

    });

    //make stake input height equals the submit button height
    jQuery('#stake-input').css('min-height', jQuery('#submit-slip-button').css('height'));
    
    //fix height bugs in featured page 
   //jQuery('.table-col-featured-options').each(function() {
       // var this_height = jQuery(this).css('height');
        //var children = jQuery(this).children('.featured-bet-option-wrapper');
        
        //jQuery(this).siblings('.table-col-featured-bet-event').css('height', this_height);
        
        //jQuery.each(children, function (index, element) {
          //  jQuery(element).css('height', this_height);
        //});
        
    //});
    
    //odd changing redirection
    jQuery('#odd-type-switcher-dropdown').on('change', function () {
        
        var selected_option = jQuery(this).find('option:selected').val();
        var current_url = window.location.href;
        var query_params = window.location.search;
        var get_symbol = (query_params === '') ? '?' : '&';
        
        //change the desired odd
        window.location.replace(current_url + get_symbol + 'odd_type_changing=' + selected_option);
    });
    
    //toggle bettings
    jQuery('span[class=toggle-btn]').on('click', function () {
        
        var selected_id = this.id;
        var selected = selected_id.split('--');
        var type = selected[0];
        var id = selected[1];
       
        var container = jQuery('#' + type + '-container-' + id);
        
        this.innerHTML = container.css('display') === 'none' ? i18n_front.toggle_symbol_minus : i18n_front.toggle_symbol_plus;
        
        container.slideToggle();
        
    });
    
    //add bet option
    jQuery('div[id^=bet-option-btn]').on('click', function () {
        
        jQuery('.bets-holder').html(i18n_front.loading);
        
        jQuery('html, body').animate({
            scrollTop: jQuery("#betslip-wrapper").offset().top - 70
        }, 1000);
        
        var selected_option_id = this.id;
        var id = selected_option_id.split('-')[3];
        var name = this.innerHTML;
        
        jQuery.post(ajaxurl, {
        
            action: 'add_bet_option',
            bet_option_id: id,
            bet_option_name: name
            
        }, function (response) {
 
            jQuery('.bets-holder').html(response);
            
        });
    });   
    
    //delete bet option
    jQuery('.bets-holder').on('click', '.delete-bet-option', function (event) {
        
        event.preventDefault();
        
        jQuery('.bets-holder').html(i18n_front.loading);
        
        var id = this.id.split('-')[1];
        
        jQuery.post(ajaxurl, {
            
            action: 'delete_bet_option',
            bet_option_id: id
            
        }, function (response) {
            
            jQuery('.bets-holder').html(response);
        });
    });
    
    //submit bet slip
    jQuery('button[id=submit-slip-button]').on('click', function (event) {
        
        event.preventDefault();
        
        jQuery(this).blur();
        
        jQuery('.bets-holder').html(i18n_front.loading);
        
        var bet_stake = jQuery('#stake-input').val();
        
        jQuery.post(ajaxurl, {
            
            action: 'submit_bet_slip',
            bet_stake: bet_stake
            
        }, function (response) {
            
            jQuery('.bets-holder').html(response);
            
            jQuery('.points-holder').html(i18n_front.loading);
            
            jQuery.post(ajaxurl, {
        
                action: 'points_change'
            
            }, function (response) {
 
                jQuery('.points-holder').html(response);
            
            });

        });
    });
    
    //slips page, toggling a slip's bet options
    jQuery('.toggle-bet-options').on('click', function () {
        
        jQuery(this).next().toggle();
        
    });

    //add bettings page
    jQuery('#betpress--category').on('change', function () {

        var $bet_options = jQuery('.betpress--add-bettings--bet-options-fields');
        $bet_options.html('');

        var $bet_options_text = jQuery('.betpress--add-bettings--bet-options-text');
        $bet_options_text.hide();

        var $category = jQuery(this);

        jQuery('input[name="category"]').val(
            $category.find('option:selected').text()
        );

        var category_ID = $category.val();
        

        if (category_ID) {

            $category.append(
                jQuery('<option value="loading" class="betpress--loading">Loading bet options...</option>')
            );
            $category.val('loading');
            $category.attr('disabled', 'disabled');

            jQuery.post(ajaxurl, {

                action: 'get_bet_options_per_category',
                category_id: category_ID,
                bet_event_id: jQuery('#betpress--bet-event').val(),
                event_id: jQuery('#betpress--event').val(),
                sport_id: jQuery('#betpress--sport').val()

            }, function (response) {

                if (response === '0') {

                    $category.find('option.betpress--loading').text('Unexpected error! Refresh the page and try again');

                } else {

                    var bet_options = JSON.parse(response);

                    var has_bet_options = false;

                    jQuery.each(bet_options, function (bet_option_id, bet_option) {

                        has_bet_options = true;

                        var $bet_option_wrapper = jQuery('<div class="betpress--add-bettings--bet-option-wrapper" />');

                        var $bet_option_name = jQuery('<input />');
                        $bet_option_name.attr('type', 'text');
                        $bet_option_name.attr('name', 'bet_options_names[' + bet_option_id + ']');
                        $bet_option_name.attr('value', bet_option.bet_option_name);
                        $bet_option_name.attr('class', 'betpress--add-bettings--bet-option-name');
                        $bet_option_name.attr('required', true);
                        $bet_option_name.attr('readonly', true); //attributo per non editare
                        $bet_option_wrapper.append($bet_option_name);
/*upload immagine
                        var $bet_option_image = jQuery('<input />');
                        $bet_option_image.attr('type', 'file');
                        $bet_option_image.attr('name', 'bet_options_images[' + id + ']');
                        $bet_option_image.attr('class', 'betpress--add-bettings--bet-option-image');
                        $bet_option_image.attr('accept', 'image/*');
                        $bet_option_wrapper.append($bet_option_image);
                        $bet_option_image.on('change', function () {
                            var $name = jQuery('input[name="bet_options_names[' + id + ']"]');
                            $name.val(
                                $name.val() + ' [image]'
                            )
                        });
*/
                        var $bet_option_odd = jQuery('<input />');
                        $bet_option_odd.attr('type', 'number');
                        $bet_option_odd.attr('min', '1.00');
                        $bet_option_odd.attr('step', '0.01');
                        $bet_option_odd.attr('max', '500');
                        $bet_option_odd.attr('name', 'bet_options_odds[' + bet_option_id + ']');
                        $bet_option_odd.attr('value', bet_option.bet_option_odd);
                        $bet_option_odd.attr('class', 'betpress--add-bettings--bet-option-odd');
                        $bet_option_odd.attr('required', true);
                        
                        $bet_option_wrapper.append($bet_option_odd);
                        
                       
                        $bet_options.append($bet_option_wrapper);

                    });

                    if (has_bet_options) {

                        $bet_options_text.show();

                    } else {

                        $bet_options.find('option.betpress--please-select').text('No categories for this game at the moment');

                    }

                    $category.attr('disabled', null)
                        .val(category_ID)
                        .find('option.betpress--loading').remove();

                }

            });

        }

    });

    jQuery('#betpress--bet-event').on('change', function () {

        var $category = jQuery('#betpress--category');
        $category.val('');
        $category.find('option.betpress--please-select').text('Please select category');
        $category.find('option:not(.betpress--please-select)').remove();
        $category.trigger('change');

        var $bet_event = jQuery(this);

        var $bet_event_input = jQuery('input[name="bet_event"]');
        $bet_event_input.val(
            $bet_event.find('option:selected').text()
        );

        var bet_event_ID = $bet_event.val();

        if (bet_event_ID) {

            jQuery('input[name="bet_event_deadline"]').val(
                $bet_event.find('option:selected').data('deadline')
            );

            //$bet_event_input.attr('type', 'text');//visualizza ed edita il campo event (inter-milan)

            $bet_event.append(
                jQuery('<option value="loading" class="betpress--loading">Loading categories...</option>')
            );
            $bet_event.val('loading');
            $bet_event.attr('disabled', 'disabled');

            jQuery.post(ajaxurl, {

                action: 'get_categories_per_bet_event',
                bet_event_id: bet_event_ID,
                event_id: jQuery('#betpress--event').val(),
                sport_id: jQuery('#betpress--sport').val()

            }, function (response) {

                if (response === '0') {

                    $bet_event.find('option.betpress--loading').text('Unexpected error! Refresh the page and try again');

                } else {

                    var categories = JSON.parse(response);

                    var has_categories = false;

                    jQuery.each(categories, function (bet_event_cat_id, bet_event_cat_name) {

                        has_categories = true;

                        $category.append(
                            jQuery('<option value="' + bet_event_cat_id + '">' + bet_event_cat_name + '</option>')
                        );

                    });

                    if (! has_categories) {

                        $category.find('option.betpress--please-select').text('No categories for this game at the moment');

                    }

                    $bet_event.attr('disabled', null)
                        .val(bet_event_ID)
                        .find('option.betpress--loading').remove();

                }

            });

        } else {

            $bet_event_input.attr('type', 'hidden');

        }

    });

    jQuery('#betpress--event').on('change', function () {

        var $bet_event = jQuery('#betpress--bet-event');
        $bet_event.val('');
        $bet_event.find('option.betpress--please-select').text('Please select game');
        $bet_event.find('option:not(.betpress--please-select)').remove();
        $bet_event.trigger('change');

        var $event = jQuery(this);

        jQuery('input[name="event"]').val(
            $event.find('option:selected').text()
        );

        var event_ID = $event.val();

        if (event_ID) {

            $event.append(
                jQuery('<option value="loading" class="betpress--loading">Loading games...</option>')
            );
            $event.val('loading');
            $event.attr('disabled', 'disabled');

            jQuery.post(ajaxurl, {

                action: 'get_bet_events_per_event',
                event_id: event_ID,
                sport_id: jQuery('#betpress--sport').val()

            }, function (response) {

                if (response === '0') {

                    $event.find('option.betpress--loading').text('Unexpected error! Refresh the page and try again');

                } else {

                    var bet_events = JSON.parse(response);

                    var has_bet_events = false;

                    jQuery.each(bet_events, function (bet_event_id, bet_event) {

                        has_bet_events = true;
                        data = new Date (bet_event.deadline);//codice funzionante per mettere la data al menu  atendina- Problema che inserisce in db anche la data col nome
                        data_lunga = bet_event.deadline*1000;// + data.toISOString().slice(0,10) +' '
                        data = new Date (data_lunga);
                        data.format =  new String("yyyy-MM-dd HH:mm:ss");

     
                        $bet_event.append(
                            jQuery('<option value="' + bet_event_id + '" data-deadline="' + bet_event.deadline + '" >' + bet_event.bet_event_name  + ' </option>' )
                        );

                    });
                    

                    if (! has_bet_events) {

                        $bet_event.find('option.betpress--please-select').text('No games for this event at the moment');

                    }
                 
                    $event.attr('disabled', null)
                        .val(event_ID)
                        .find('option.betpress--loading').remove();

                }

            });

        }

    });

    jQuery('#betpress--sport').on('change', function () {

        var $event = jQuery('#betpress--event');
        $event.val('');
        $event.find('option.betpress--please-select').text('Please select event');
        $event.find('option:not(.betpress--please-select)').remove();
        $event.trigger('change');

        var $sport = jQuery(this);

        jQuery('input[name="sport"]').val(
            $sport.find('option:selected').text()
        );

        var sport_ID = $sport.val();

        if (sport_ID) {

            $sport.append(
                jQuery('<option value="loading" class="betpress--loading">Loading events...</option>')
            );
            $sport.val('loading');
            $sport.attr('disabled', 'disabled');

            jQuery.post(ajaxurl, {

                action: 'get_events_per_sport',
                sport_id: sport_ID

            }, function (response) {

                if (response === '0') {

                    $sport.find('option.betpress--loading').text('Unexpected error! Refresh the page and try again');

                } else {

                    var events = JSON.parse(response);

                    var has_events = false;

                    jQuery.each(events, function (event_id, event_name) {

                        has_events = true;

                        $event.append(
                            jQuery('<option value="' + event_id + '">' + event_name + '</option>')
                        );

                    });

                    if (! has_events) {

                        $event.find('option.betpress--please-select').text('No events for this sport at the moment');

                    }
                    $sport.attr('disabled', null)
                        .val(sport_ID)
                        .find('option.betpress--loading').remove();

                }

            });

        }

    });
	
    //add question page

    function betpress_change_answer_row($answer, value, clearTitle, preserveSelected) {

        var clonedAnswerTitle = $answer.find('.betpress--add-question--answer-title-field input');

        var clonedAnswerTitlePlaceholder = clonedAnswerTitle.attr('placeholder');

        clonedAnswerTitle.attr('placeholder', clonedAnswerTitlePlaceholder.substr(0, clonedAnswerTitlePlaceholder.length - 1) + value)

            .attr('name', 'answers[' + value + ']');


        $answer.find('.betpress--add-question--answer-upload-field input')

            .attr('name', 'uploads[' + value + ']');


        $answer.find('.betpress--add-question--answer-is-correct-field input').val(value);


        if (clearTitle) {

            clonedAnswerTitle.val('');

        }


        if (! preserveSelected) {

            $answer.find('.betpress--add-question--answer-is-correct-field input').prop('checked', false);

        }

    }


    jQuery('#betpress--add-question--add-new-answer').on('click', function (e) {


        e.preventDefault();


        var answersFields = jQuery('.betpress--add-question--answers-fields');


        var latestRow = answersFields.data('number-of-showed-answers');


        var nextRow = 1 + latestRow;


        answersFields.data('number-of-showed-answers', nextRow);


        var latestAnswer = jQuery('.betpress--add-question--answer-field').last();


        var clonedAnswer = latestAnswer.clone();


        betpress_change_answer_row(clonedAnswer, nextRow, true, false);


        clonedAnswer.insertAfter(latestAnswer);


        if (nextRow > 2) {


            jQuery('.betpress--add-question--remove-answer-row').show();


        }


    })


    var $answersFields = jQuery('.betpress--add-question--answers-fields');


    $answersFields.on('click', '.betpress--add-question--remove-answer-row', function (e) {


        e.preventDefault();


        var answersFields = jQuery('.betpress--add-question--answers-fields');


        var latestRow = answersFields.data('number-of-showed-answers');


        var newNumberOfShowedAnswers = parseInt(latestRow) - 1;


        answersFields.data('number-of-showed-answers', newNumberOfShowedAnswers);


        jQuery(this).parent().remove();


        jQuery('.betpress--add-question--answer-field').each(function (index, answer) {


            betpress_change_answer_row(jQuery(answer), 1 + index, false, true);


        })


        if (newNumberOfShowedAnswers <= 2) {


            jQuery('.betpress--add-question--remove-answer-row').hide();


        }


    });


    $answersFields.on('change', '.betpress--add-question--answer-upload-input', function (e) {


        e.preventDefault();


        var $answerTitleInput = jQuery(this).parents('.betpress--add-question--answer-field')

            .first()

            .find('.betpress--add-question--answer-title-field input');


        $answerTitleInput.val(

            $answerTitleInput.val() + ' [image]'

        );


    })
  
    jQuery('.betpress--add-question--question-upload-input').on('change', function () {


        var $questionTitleInput = jQuery('.betpress--add-question--question-title-field input');


        $questionTitleInput.val(

            $questionTitleInput.val() + ' [image]'

        );


    })
  
});

//add promises page
jQuery('#ilboos--category').on('change', function () {

    var $bet_options = jQuery('.ilboos--add-promises--bet-options-fields');
    $bet_options.html('');

    var $bet_options_text = jQuery('.ilboos--add-promises--bet-options-text');
    $bet_options_text.hide();

    var $category = jQuery(this);

    jQuery('input[name="category"]').val(
      $category.find('option:selected').text()
    );

    var category_ID = $category.val();
    

    if (category_ID) {

        $category.append(
            jQuery('<option value="loading" class="betpress--loading">Loading bet options...</option>')
        );
        $category.val('loading');
        $category.attr('disabled', 'disabled');

        jQuery.post(ajaxurl, {

            action: 'get_bet_options_per_category',
            category_id: category_ID,
            bet_event_id: jQuery('#betpress--bet-event').val(),
            event_id: jQuery('#betpress--event').val(),
            sport_id: jQuery('#ilboos--sport').val()

        }, function (response) {

            if (response === '0') {

                $category.find('option.betpress--loading').text('Unexpected error! Refresh the page and try again');

            } else {

                var bet_options = JSON.parse(response);

                var has_bet_options = false;

                jQuery.each(bet_options, function (id, bet_option) {

                    has_bet_options = true;

                    var $bet_option_wrapper = jQuery('<div class="ilboos--add-promises--bet-option-wrapper" />');

                    var $bet_option_name = jQuery('<input />');
                    $bet_option_name.attr('type', 'text');
                    $bet_option_name.attr('name', 'bet_options_names[' + id + ']');
                    $bet_option_name.attr('value', bet_option.name);
                    $bet_option_name.attr('class', 'ilboos--add-promises--bet-option-name');
                    $bet_option_name.attr('required', true);
                    $bet_option_name.attr('readonly', true); //attributo per non editare
                    $bet_option_wrapper.append($bet_option_name);
/*upload immagine
                    var $bet_option_image = jQuery('<input />');
                    $bet_option_image.attr('type', 'file');
                    $bet_option_image.attr('name', 'bet_options_images[' + id + ']');
                    $bet_option_image.attr('class', 'ilboos--add-promises--bet-option-image');
                    $bet_option_image.attr('accept', 'image/*');
                    $bet_option_wrapper.append($bet_option_image);
                    $bet_option_image.on('change', function () {
                        var $name = jQuery('input[name="bet_options_names[' + id + ']"]');
                        $name.val(
                            $name.val() + ' [image]'
                        )
                    });
*/
                    var $bet_option_odd = jQuery('<input />');
                    $bet_option_odd.attr('type', 'number');
                    $bet_option_odd.attr('min', '1.00');
                    $bet_option_odd.attr('step', '0.01');
                    $bet_option_odd.attr('max', '500');
                    $bet_option_odd.attr('name', 'bet_options_odds[' + id + ']');
                    $bet_option_odd.attr('value', bet_option.odd);
                    $bet_option_odd.attr('class', 'ilboos--add-promises--bet-option-odd');
                    $bet_option_odd.attr('required', true);
                    
                    $bet_option_wrapper.append($bet_option_odd);
                    
                   
                    $bet_options.append($bet_option_wrapper);

                });

                if (has_bet_options) {

                    $bet_options_text.show();

                } else {

                    $bet_options.find('option.betpress--please-select').text('No categories for this game at the moment');

                }

                $category.attr('disabled', null)
                    .val(category_ID)
                    .find('option.betpress--loading').remove();

            }

        });

    }

});

jQuery('#ilboos--bet-event').on('change', function () {

    var $category = jQuery('#ilboos--category');
    $category.val('');
    //$category.find('option.betpress--please-select').text('Please select category');
    $category.find('option:not(.betpress--please-select)').remove();
    $category.trigger('change');

    var $bet_event = jQuery(this);

    var $bet_event_input = jQuery('input[name="bet_event"]');
    $bet_event_input.val(
        $bet_event.find('option:selected').text()
    );

    var bet_event_ID = $bet_event.val();




});

jQuery('#ilboos--event').on('change', function () {

    var $bet_event = jQuery('#ilboos--bet-event');
    $bet_event.val('');
    $bet_event.find('option.betpress--please-select').text('Please select game');
    $bet_event.find('option:not(.betpress--please-select)').remove();
    $bet_event.trigger('change');

    var $event = jQuery(this);

    jQuery('input[name="event"]').val(
        $event.find('option:selected').text()
    );

    var event_ID = $event.val();

    if (event_ID) {

        $event.append(
            jQuery('<option value="loading" class="betpress--loading">Loading games...</option>')
        );
        $event.val('loading');
        $event.attr('disabled', 'disabled');

        jQuery.post(ajaxurl, {

            action: 'get_bet_events_per_event',
            event_id: event_ID,
            sport_id: jQuery('#ilboos--sport').val()

        }, function (response) {

            if (response === '0') {

                $event.find('option.betpress--loading').text('Unexpected error! Refresh the page and try again');

            } else {

                var bet_events = JSON.parse(response);

                var has_bet_events = false;

                jQuery.each(bet_events, function (id, bet_event) {

                    has_bet_events = true;
  data = new Date (bet_event.deadline);//codice funzionante per mettere la data al menu  atendina- Problema che inserisce in db anche la data col nome
  data_lunga = bet_event.deadline*1000;// + data.toISOString().slice(0,10) +' '
  data = new Date (data_lunga);
  data.format =  new String("yyyy-MM-dd HH:mm:ss");

 
                    $bet_event.append(
                        jQuery('<option value="' + id + '" data-deadline="' + bet_event.deadline + '">' + bet_event.name  +      '   </option>' )
                    );

                });
                

                if (! has_bet_events) {

                    $bet_event.find('option.betpress--please-select').text('No games for this event at the moment');

                }
             
                $event.attr('disabled', null)
                    .val(event_ID)
                    .find('option.betpress--loading').remove();

            }

        });

    }

});

jQuery('#ilboos--sport').on('change', function () {

    var $event = jQuery('#ilboos--event');
    $event.val('');
    $event.find('option.betpress--please-select').text('Please select event');
    $event.find('option:not(.betpress--please-select)').remove();
    $event.trigger('change');

    var $sport = jQuery(this);

    jQuery('input[name="sport"]').val(
        $sport.find('option:selected').text()
    );

    var sport_ID = $sport.val();

    if (sport_ID) {

        $sport.append(
            jQuery('<option value="loading" class="betpress--loading">Loading events...</option>')
        );
        $sport.val('loading');
        $sport.attr('disabled', 'disabled');

        jQuery.post(ajaxurl, {

            action: 'get_events_per_sport',
            sport_id: sport_ID

        }, function (response) {

            if (response === '0') {

                $sport.find('option.betpress--loading').text('Unexpected error! Refresh the page and try again');

            } else {

                var events = JSON.parse(response);

                var has_events = false;

                jQuery.each(events, function (id, name) {

                    has_events = true;

                    $event.append(
                        jQuery('<option value="' + id + '">' + name + '</option>')
                    );

                });

                if (! has_events) {

                    $event.find('option.betpress--please-select').text('No events for this sport at the moment');

                }
                $sport.attr('disabled', null)
                    .val(sport_ID)
                    .find('option.betpress--loading').remove;

            }

        });

    }

});