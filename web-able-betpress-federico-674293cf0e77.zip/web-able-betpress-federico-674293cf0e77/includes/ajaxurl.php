<?php
//don't allow direct access via url
if ( ! defined('ABSPATH') ) {
    exit();
}
?>
<script type="text/javascript">
    
    var ajaxurl = "<?php echo admin_url('admin-ajax.php') ?>";
    
</script>